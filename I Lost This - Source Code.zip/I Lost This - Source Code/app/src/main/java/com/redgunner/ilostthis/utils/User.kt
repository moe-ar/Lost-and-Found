package com.redgunner.ilostthis.utils

data class User( var FullName: String="",
                 var Email: String="",
                 var Country: String="",
                 var City: String="",
                 var AddressOne: String="",
                 var PhoneNumber:String=""
                 ) {




}