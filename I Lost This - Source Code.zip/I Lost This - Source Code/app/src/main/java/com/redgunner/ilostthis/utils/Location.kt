package com.redgunner.ilostthis.utils

data class Location(var location:String="")
